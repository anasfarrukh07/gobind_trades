# Org-Scoped Skill Registry Backend

A production-grade FastAPI backend service for managing organization-scoped, versioned agent skills with strict tenant isolation, immutable version history, owner-controlled lifecycle activation, tool security validation, and comprehensive audit logging.

---

## 🌟 Key Features

1. **Strict Multi-Tenant Isolation**: Every API request is resolved to an authenticated `organization_id` via JWT tokens. Queries explicitly filter by `org_id`. Cross-tenant requests return `404 Not Found` to prevent resources/existence leakage.
2. **Immutable Versioning**: Active skill versions are read-only. Editing an active skill creates Version N+1 in `pending_review` status without mutating existing version rows.
3. **Owner-Only Lifecycle Activation**: Only organization `owner` users can activate a skill version (`draft`/`pending_review` -> `active`). Activating supersedes any previous active version.
4. **Idempotent Activation**: Re-activating an active version is a safe no-op (returns HTTP 200 without state corruption or duplicate audit logs).
5. **Tool Permission Denylist**: Rejects invalid or destructive tool names (`exec_shell`, `rm_rf`, `sudo`, `eval`, `system`, etc.) at creation/version submission time with `400 Bad Request`.
6. **Runtime Selection Scoping**: `GET /departments/{dept}/active-skills` returns active skills for a department and excludes `draft` or `disabled` skills.
7. **Comprehensive Audit Logging**: Automatically records `version_created`, `version_activated`, and `skill_disabled` events with timestamp, tenant, actor, skill ID, and version ID.

---

## 🏗️ Stack & Architecture

- **Framework**: FastAPI (Python 3.11)
- **Database**: PostgreSQL 15 (ORM: SQLAlchemy 2.0 with Alembic migrations)
- **Authentication**: JWT (Bearer tokens encoding `user_id`, `org_id`, `role`)
- **Containerization**: Docker & Docker Compose (`api` + `postgres`)
- **Testing**: Pytest & HTTPX test suite (100% real DB assertions, 10/10 test scenarios passing)

---

## 🚀 Quick Start (One-Command Local Startup)

### Prerequisites
- Docker Engine & Docker Compose installed.

### 1. Launch Services
Run Docker Compose to start PostgreSQL and the FastAPI server:

```bash
docker-compose up --build
```

The container automatically:
1. Waits for PostgreSQL health check.
2. Runs database migrations (`alembic upgrade head`).
3. Seeds initial fixture data (`python -m app.seed`).
4. Starts the API server at `http://localhost:8000`.

### 2. Swagger / OpenAPI Documentation
Interactive API docs are available at:
- `http://localhost:8000/docs` (Swagger UI)
- `http://localhost:8000/redoc` (ReDoc)

---

## 🔑 Pre-Seeded Test Credentials

| Organization | Role | Email | Password |
| :--- | :--- | :--- | :--- |
| **ABC Construction** | Owner | `owner@abc.com` | `Password123!` |
| **ABC Construction** | Member | `member@abc.com` | `Password123!` |
| **XYZ Builders** | Owner | `owner@xyz.com` | `Password123!` |
| **XYZ Builders** | Member | `member@xyz.com` | `Password123!` |

---

## 🧪 Running Automated Tests

Run the full pytest suite locally:

```bash
# Setup virtual environment (if running locally without Docker)
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Run pytest
pytest -v
```

All 10 test scenarios pass:
1. `test_1_same_org_create_and_read_succeeds`
2. `test_2_cross_org_read_is_denied`
3. `test_3_cross_org_update_is_denied`
4. `test_4_non_owner_activation_is_denied`
5. `test_5_draft_skill_cannot_be_selected_as_active`
6. `test_6_disabled_skill_excluded_from_active_query`
7. `test_7_active_version_cannot_be_mutated_in_place`
8. `test_8_duplicate_activation_is_idempotent`
9. `test_9_invalid_destructive_requested_tool_is_rejected`
10. `test_10_audit_record_contains_org_actor_event_type_and_version`

---

## 📡 Complete cURL / HTTPie API Workflow

### Step 1: Authenticate as ABC Owner & ABC Member

```bash
# Obtain Owner Token
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "owner@abc.com", "password": "Password123!"}'

# Save token:
EXPORT OWNER_TOKEN="<access_token_here>"
```

---

### Step 2: Create a Draft Skill (Version 1)

```bash
curl -X POST "http://localhost:8000/skills" \
  -H "Authorization: Bearer $OWNER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Site Safety Inspection",
    "department": "Safety",
    "content": {
      "instructions": "Inspect scaffolding and verify harness gear",
      "max_tokens": 1000
    },
    "requested_tools": ["read_file", "search_web"]
  }'
```

*Response (201 Created):*
```json
{
  "id": "e4a2b1c9-...",
  "org_id": "org-abc-id",
  "name": "Site Safety Inspection",
  "department": "Safety",
  "status": "draft",
  "current_active_version_id": null,
  "versions": [
    {
      "id": "ver-1-id",
      "version_number": 1,
      "status": "pending_review",
      "requested_tools": ["read_file", "search_web"]
    }
  ]
}
```

---

### Step 3: Attempt Non-Owner Activation (Fails 403)

```bash
# Log in as ABC Member
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "member@abc.com", "password": "Password123!"}'

EXPORT MEMBER_TOKEN="<member_token_here>"

# Attempt activation as member
curl -X POST "http://localhost:8000/skills/SKILL_ID/versions/VER_1_ID/activate" \
  -H "Authorization: Bearer $MEMBER_TOKEN"
```

*Response (403 Forbidden):*
```json
{
  "detail": "Operation permitted for organization owners only"
}
```

---

### Step 4: Activate Version 1 as Owner

```bash
curl -X POST "http://localhost:8000/skills/SKILL_ID/versions/VER_1_ID/activate" \
  -H "Authorization: Bearer $OWNER_TOKEN"
```

*Response (200 OK):*
```json
{
  "id": "SKILL_ID",
  "status": "active",
  "current_active_version_id": "VER_1_ID"
}
```

---

### Step 5: Verify Idempotent Activation (Duplicate Call)

```bash
# Call activation endpoint again on active version
curl -X POST "http://localhost:8000/skills/SKILL_ID/versions/VER_1_ID/activate" \
  -H "Authorization: Bearer $OWNER_TOKEN"
```
*Returns HTTP 200 OK cleanly as a safe no-op without creating duplicate audit log entries.*

---

### Step 6: Create Version 2 (Immutable Edit)

```bash
curl -X POST "http://localhost:8000/skills/SKILL_ID/versions" \
  -H "Authorization: Bearer $OWNER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": {
      "instructions": "Updated safety protocols for 2026 OSHA standards"
    },
    "requested_tools": ["read_file"]
  }'
```
*Creates Version 2 with status `pending_review` without mutating Version 1.*

---

### Step 7: Query Department Active Skills

```bash
curl -X GET "http://localhost:8000/departments/Safety/active-skills" \
  -H "Authorization: Bearer $OWNER_TOKEN"
```
*Returns list containing the active skill version.*

---

### Step 8: Test Tool Denylist Rejection (Destructive Tool)

```bash
curl -X POST "http://localhost:8000/skills" \
  -H "Authorization: Bearer $OWNER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Malicious Skill",
    "department": "IT",
    "content": {"cmd": "run"},
    "requested_tools": ["rm_rf", "exec_shell"]
  }'
```
*Response (422 Unprocessable Entity / 400 Bad Request):*
```json
{
  "detail": [
    {
      "msg": "Value error, Requested tool 'rm_rf' is invalid or contains forbidden destructive patterns."
    }
  ]
}
```

---

### Step 9: Verify Cross-Org Isolation (XYZ Owner Access)

```bash
# Log in as XYZ Owner
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "owner@xyz.com", "password": "Password123!"}'

EXPORT XYZ_TOKEN="<xyz_token>"

# Attempt to access ABC's skill
curl -X GET "http://localhost:8000/skills/ABC_SKILL_ID" \
  -H "Authorization: Bearer $XYZ_TOKEN"
```
*Response (404 Not Found):*
```json
{
  "detail": "Skill not found"
}
```

---

### Step 10: Check Audit Logs

```bash
curl -X GET "http://localhost:8000/audit-logs" \
  -H "Authorization: Bearer $OWNER_TOKEN"
```

*Returns audit logs for tenant org containing `version_created` and `version_activated` records.*
