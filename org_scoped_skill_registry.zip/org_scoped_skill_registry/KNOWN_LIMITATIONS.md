# Known Limitations & Trade-Offs

## 1. Single-Field Tool Denylist (Rule-Based Validation)
- Current tool validation uses a static denylist (`settings.TOOL_DENYLIST`) and keyword matching for high-risk tools (`rm_rf`, `exec_shell`, `sudo`, `eval`, `system`).
- **Future Improvement**: Implement fine-grained JSON schema validation for tool parameter definitions and an allowable tool whitelist per organization.

## 2. In-Memory Session / JWT Revocation
- JWT tokens are stateless and expire after `ACCESS_TOKEN_EXPIRE_MINUTES` (default 24h). There is no distributed token revocation list (e.g. Redis blocklist).
- **Future Improvement**: Integrate Redis for token blacklisting on logout or user role change.

## 3. Direct DB Row-Level Security (RLS)
- Tenant isolation currently relies on application-level filtering (`filter(Skill.org_id == current_user.org_id)`).
- **Future Improvement**: Enforce PostgreSQL Row-Level Security (RLS) policies at the database layer for defense-in-depth against application query bugs.

## 4. Single Active Version per Skill
- Each skill supports exactly one active version at a time (`current_active_version_id`).
- **Future Improvement**: Support canary deployments or A/B version rollouts (e.g., 90% version 1, 10% version 2).
