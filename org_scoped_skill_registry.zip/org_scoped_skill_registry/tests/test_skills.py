import pytest
from app.models.skill import Skill
from app.models.skill_version import SkillVersion
from app.models.audit_log import AuditLog

def test_1_same_org_create_and_read_succeeds(client, fixture_data):
    """TEST 1: Same-org create + read succeeds"""
    headers = fixture_data["headers_abc_owner"]
    payload = {
        "name": "Safety Protocol",
        "department": "Engineering",
        "content": {"prompt": "Perform site safety inspection", "max_tokens": 500},
        "requested_tools": ["read_file", "search_web"]
    }
    
    # Create draft skill
    res_create = client.post("/skills", json=payload, headers=headers)
    assert res_create.status_code == 201, res_create.text
    data_create = res_create.json()
    assert data_create["name"] == "Safety Protocol"
    assert data_create["department"] == "Engineering"
    assert data_create["status"] == "draft"
    assert len(data_create["versions"]) == 1
    assert data_create["versions"][0]["version_number"] == 1
    assert data_create["versions"][0]["status"] == "pending_review"

    skill_id = data_create["id"]

    # Read back via GET /skills
    res_list = client.get("/skills", headers=headers)
    assert res_list.status_code == 200
    skills = res_list.json()
    assert any(s["id"] == skill_id for s in skills)

    # Read back via GET /skills/{id}
    res_get = client.get(f"/skills/{skill_id}", headers=headers)
    assert res_get.status_code == 200
    assert res_get.json()["id"] == skill_id


def test_2_cross_org_read_is_denied(client, fixture_data):
    """TEST 2: Cross-org read is denied (404/403)"""
    abc_headers = fixture_data["headers_abc_owner"]
    xyz_headers = fixture_data["headers_xyz_owner"]

    # ABC creates skill
    res_create = client.post(
        "/skills",
        json={
            "name": "ABC Secret Blueprint",
            "department": "Architecture",
            "content": {"data": "confidential"},
            "requested_tools": []
        },
        headers=abc_headers
    )
    skill_id = res_create.json()["id"]

    # XYZ attempts to read ABC skill
    res_read = client.get(f"/skills/{skill_id}", headers=xyz_headers)
    assert res_read.status_code in [403, 404]
    assert "detail" in res_read.json()


def test_3_cross_org_update_is_denied(client, fixture_data):
    """TEST 3: Cross-org update is denied"""
    abc_headers = fixture_data["headers_abc_owner"]
    xyz_headers = fixture_data["headers_xyz_owner"]

    # ABC creates skill
    res_create = client.post(
        "/skills",
        json={
            "name": "Concrete Mixing",
            "department": "Operations",
            "content": {"ratio": "1:2:4"},
            "requested_tools": []
        },
        headers=abc_headers
    )
    skill_id = res_create.json()["id"]
    version_id = res_create.json()["versions"][0]["id"]

    # XYZ attempts to create new version for ABC skill
    res_ver = client.post(
        f"/skills/{skill_id}/versions",
        json={"content": {"ratio": "hacked"}, "requested_tools": []},
        headers=xyz_headers
    )
    assert res_ver.status_code in [403, 404]

    # XYZ attempts to activate ABC version
    res_act = client.post(f"/skills/{skill_id}/versions/{version_id}/activate", headers=xyz_headers)
    assert res_act.status_code in [403, 404]

    # XYZ attempts to disable ABC skill
    res_dis = client.post(f"/skills/{skill_id}/disable", headers=xyz_headers)
    assert res_dis.status_code in [403, 404]


def test_4_non_owner_activation_is_denied(client, fixture_data):
    """TEST 4: Non-owner activation is denied"""
    abc_owner = fixture_data["headers_abc_owner"]
    abc_member = fixture_data["headers_abc_member"]

    # ABC owner creates draft skill
    res_create = client.post(
        "/skills",
        json={
            "name": "Crane Operation",
            "department": "Heavy Machinery",
            "content": {"safety": "high"},
            "requested_tools": []
        },
        headers=abc_owner
    )
    skill_id = res_create.json()["id"]
    version_id = res_create.json()["versions"][0]["id"]

    # ABC member attempts to activate version
    res_act = client.post(
        f"/skills/{skill_id}/versions/{version_id}/activate",
        headers=abc_member
    )
    assert res_act.status_code == 403
    assert "owners only" in res_act.json()["detail"].lower()


def test_5_draft_skill_cannot_be_selected_as_active(client, fixture_data):
    """TEST 5: Draft skill cannot be selected/loaded as "active" anywhere"""
    abc_owner = fixture_data["headers_abc_owner"]

    # Create draft skill in HVAC department
    res_create = client.post(
        "/skills",
        json={
            "name": "HVAC Inspection Draft",
            "department": "HVAC",
            "content": {"step": 1},
            "requested_tools": []
        },
        headers=abc_owner
    )
    skill_id = res_create.json()["id"]

    # Query active skills for HVAC department
    res_dept = client.get("/departments/HVAC/active-skills", headers=abc_owner)
    assert res_dept.status_code == 200
    active_skills = res_dept.json()
    assert not any(s["id"] == skill_id for s in active_skills)


def test_6_disabled_skill_excluded_from_active_query(client, fixture_data):
    """TEST 6: Disabled skill excluded from active-skills query"""
    abc_owner = fixture_data["headers_abc_owner"]

    # Create skill in Plumbing department
    res_create = client.post(
        "/skills",
        json={
            "name": "Pipe Fitting",
            "department": "Plumbing",
            "content": {"spec": "ANSI"},
            "requested_tools": []
        },
        headers=abc_owner
    )
    skill_id = res_create.json()["id"]
    version_id = res_create.json()["versions"][0]["id"]

    # Activate skill
    res_act = client.post(f"/skills/{skill_id}/versions/{version_id}/activate", headers=abc_owner)
    assert res_act.status_code == 200

    # Verify present in department active skills
    res_dept1 = client.get("/departments/Plumbing/active-skills", headers=abc_owner)
    assert any(s["id"] == skill_id for s in res_dept1.json())

    # Disable skill
    res_dis = client.post(f"/skills/{skill_id}/disable", headers=abc_owner)
    assert res_dis.status_code == 200
    assert res_dis.json()["status"] == "disabled"

    # Query active skills again -> excluded!
    res_dept2 = client.get("/departments/Plumbing/active-skills", headers=abc_owner)
    assert not any(s["id"] == skill_id for s in res_dept2.json())


def test_7_active_version_cannot_be_mutated_in_place(client, fixture_data, db_session):
    """TEST 7: Active version cannot be mutated (attempt in-place edit -> creates new version instead)"""
    abc_owner = fixture_data["headers_abc_owner"]

    # Create & activate version 1
    res_create = client.post(
        "/skills",
        json={
            "name": "Electrical Wiring",
            "department": "Electrical",
            "content": {"wire_gauge": "12 AWG"},
            "requested_tools": []
        },
        headers=abc_owner
    )
    skill_id = res_create.json()["id"]
    v1_id = res_create.json()["versions"][0]["id"]

    client.post(f"/skills/{skill_id}/versions/{v1_id}/activate", headers=abc_owner)

    # Edit skill -> Creates version 2
    res_v2 = client.post(
        f"/skills/{skill_id}/versions",
        json={"content": {"wire_gauge": "10 AWG"}, "requested_tools": []},
        headers=abc_owner
    )
    assert res_v2.status_code == 201
    v2_data = res_v2.json()
    assert v2_data["version_number"] == 2
    assert v2_data["id"] != v1_id
    assert v2_data["status"] == "pending_review"

    # Verify Version 1 in DB remains intact with wire_gauge 12 AWG
    v1_db = db_session.query(SkillVersion).filter(SkillVersion.id == v1_id).first()
    assert v1_db.content == {"wire_gauge": "12 AWG"}
    assert v1_db.version_number == 1


def test_8_duplicate_activation_is_idempotent(client, fixture_data, db_session):
    """TEST 8: Duplicate activation call is idempotent (no error, no duplicate state corruption)"""
    abc_owner = fixture_data["headers_abc_owner"]

    # Create skill
    res_create = client.post(
        "/skills",
        json={
            "name": "Roofing Standards",
            "department": "Structural",
            "content": {"material": "Shingles"},
            "requested_tools": []
        },
        headers=abc_owner
    )
    skill_id = res_create.json()["id"]
    v1_id = res_create.json()["versions"][0]["id"]

    # Activate version 1 (first time)
    res_act1 = client.post(f"/skills/{skill_id}/versions/{v1_id}/activate", headers=abc_owner)
    assert res_act1.status_code == 200

    # Count audit logs for activation before duplicate call
    audit_count_before = db_session.query(AuditLog).filter(
        AuditLog.skill_id == skill_id,
        AuditLog.event_type == "version_activated"
    ).count()
    assert audit_count_before == 1

    # Activate version 1 (second time - duplicate call)
    res_act2 = client.post(f"/skills/{skill_id}/versions/{v1_id}/activate", headers=abc_owner)
    assert res_act2.status_code == 200
    assert res_act2.json()["status"] == "active"

    # Verify no extra duplicate audit log was written
    audit_count_after = db_session.query(AuditLog).filter(
        AuditLog.skill_id == skill_id,
        AuditLog.event_type == "version_activated"
    ).count()
    assert audit_count_after == 1


def test_9_invalid_destructive_requested_tool_is_rejected(client, fixture_data):
    """TEST 9: Invalid/destructive requested tool is rejected at creation"""
    abc_owner = fixture_data["headers_abc_owner"]

    # Attempt to create skill with forbidden tool 'rm_rf'
    res_bad1 = client.post(
        "/skills",
        json={
            "name": "Dangerous Skill",
            "department": "IT",
            "content": {"cmd": "cleanup"},
            "requested_tools": ["rm_rf"]
        },
        headers=abc_owner
    )
    assert res_bad1.status_code in [400, 422]

    # Attempt to create skill with forbidden tool 'exec_shell'
    res_bad2 = client.post(
        "/skills",
        json={
            "name": "Shell Skill",
            "department": "IT",
            "content": {"cmd": "bash"},
            "requested_tools": ["exec_shell"]
        },
        headers=abc_owner
    )
    assert res_bad2.status_code in [400, 422]

    # Attempt to create version with 'sudo' tool
    # First create valid skill
    res_valid = client.post(
        "/skills",
        json={
            "name": "Valid Skill",
            "department": "IT",
            "content": {"cmd": "info"},
            "requested_tools": ["read_file"]
        },
        headers=abc_owner
    )
    skill_id = res_valid.json()["id"]

    res_bad_ver = client.post(
        f"/skills/{skill_id}/versions",
        json={"content": {"cmd": "sudo"}, "requested_tools": ["sudo"]},
        headers=abc_owner
    )
    assert res_bad_ver.status_code in [400, 422]


def test_10_audit_record_contains_org_actor_event_type_and_version(client, fixture_data):
    """TEST 10: Audit record contains org, actor, event type, and version reference"""
    abc_owner = fixture_data["headers_abc_owner"]
    abc_user_id = fixture_data["abc_owner"].id
    org_id = fixture_data["org_abc"].id

    # Create & activate skill
    res_create = client.post(
        "/skills",
        json={
            "name": "Audit Tracked Skill",
            "department": "Compliance",
            "content": {"checklist": ["ISO9001"]},
            "requested_tools": ["read_file"]
        },
        headers=abc_owner
    )
    skill_id = res_create.json()["id"]
    v1_id = res_create.json()["versions"][0]["id"]

    client.post(f"/skills/{skill_id}/versions/{v1_id}/activate", headers=abc_owner)

    # Query audit logs endpoint
    res_audit = client.get("/audit-logs", headers=abc_owner)
    assert res_audit.status_code == 200
    logs = res_audit.json()

    # Verify version_created log
    created_log = next((l for l in logs if l["skill_id"] == skill_id and l["event_type"] == "version_created"), None)
    assert created_log is not None
    assert created_log["org_id"] == org_id
    assert created_log["actor_id"] == abc_user_id
    assert created_log["version_id"] == v1_id

    # Verify version_activated log
    activated_log = next((l for l in logs if l["skill_id"] == skill_id and l["event_type"] == "version_activated"), None)
    assert activated_log is not None
    assert activated_log["org_id"] == org_id
    assert activated_log["actor_id"] == abc_user_id
    assert activated_log["version_id"] == v1_id
