import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.models.organization import Organization
from app.models.user import User
from app.auth.jwt import get_password_hash, create_access_token

# Use SQLite in-memory for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(scope="session", autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def db_session():
    connection = engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)
    
    yield session
    
    session.close()
    transaction.rollback()
    connection.close()

@pytest.fixture
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()

@pytest.fixture
def fixture_data(db_session):
    # Org 1: ABC Construction
    org_abc = Organization(name="ABC Construction")
    db_session.add(org_abc)
    db_session.flush()

    abc_owner = User(
        org_id=org_abc.id,
        email="owner@abc.com",
        role="owner",
        hashed_password=get_password_hash("Password123!")
    )
    abc_member = User(
        org_id=org_abc.id,
        email="member@abc.com",
        role="member",
        hashed_password=get_password_hash("Password123!")
    )
    db_session.add(abc_owner)
    db_session.add(abc_member)

    # Org 2: XYZ Builders
    org_xyz = Organization(name="XYZ Builders")
    db_session.add(org_xyz)
    db_session.flush()

    xyz_owner = User(
        org_id=org_xyz.id,
        email="owner@xyz.com",
        role="owner",
        hashed_password=get_password_hash("Password123!")
    )
    xyz_member = User(
        org_id=org_xyz.id,
        email="member@xyz.com",
        role="member",
        hashed_password=get_password_hash("Password123!")
    )
    db_session.add(xyz_owner)
    db_session.add(xyz_member)

    db_session.commit()

    token_abc_owner = create_access_token(
        data={"sub": abc_owner.id, "org_id": org_abc.id, "role": "owner", "email": abc_owner.email}
    )
    token_abc_member = create_access_token(
        data={"sub": abc_member.id, "org_id": org_abc.id, "role": "member", "email": abc_member.email}
    )
    token_xyz_owner = create_access_token(
        data={"sub": xyz_owner.id, "org_id": org_xyz.id, "role": "owner", "email": xyz_owner.email}
    )
    token_xyz_member = create_access_token(
        data={"sub": xyz_member.id, "org_id": org_xyz.id, "role": "member", "email": xyz_member.email}
    )

    return {
        "org_abc": org_abc,
        "abc_owner": abc_owner,
        "abc_member": abc_member,
        "headers_abc_owner": {"Authorization": f"Bearer {token_abc_owner}"},
        "headers_abc_member": {"Authorization": f"Bearer {token_abc_member}"},
        "org_xyz": org_xyz,
        "xyz_owner": xyz_owner,
        "xyz_member": xyz_member,
        "headers_xyz_owner": {"Authorization": f"Bearer {token_xyz_owner}"},
        "headers_xyz_member": {"Authorization": f"Bearer {token_xyz_member}"},
    }
