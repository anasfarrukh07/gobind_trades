# Architecture Decision Record (ADR)

## 1. Why PostgreSQL?

- **Relational Integrity & Foreign Key Constraints**: PostgreSQL handles relational constraints (e.g. `skills` referencing `organizations` and `skill_versions`, while `skills.current_active_version_id` points back to `skill_versions.id`) safely.
- **ACID Transactions**: Activating a new version requires updating `skill.status`, `skill.current_active_version_id`, `version.status`, and superseding prior active versions atomically. PostgreSQL guarantees atomic commits so partial state transitions never occur.
- **JSON / Structured Data Support**: PostgreSQL natively supports JSON data types, enabling seamless storage and querying of skill `content` configs and `requested_tools` lists without requiring schema migrations every time skill configuration schemas evolve.
- **Production Scoping**: While SQLite can be used for fast in-memory pytest unit testing, PostgreSQL is the production standard for containerized multi-tenant backend services.

---

## 2. Multi-Tenant Isolation Enforcement

### Strategy: Software-Enforced Column Scoping (`org_id`)

Every authenticated request resolves to exactly one `organization_id` extracted from the cryptographically verified JWT token payload:

```python
def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    token_data = decode_access_token(token)
    user = db.query(User).filter(User.id == token_data.user_id).first()
    if user.org_id != token_data.org_id:
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    return user
```

### Absolute Query Filtering
All DB queries filter explicitly by `org_id == current_user.org_id`:

```python
skill = db.query(Skill).filter(
    Skill.id == skill_id,
    Skill.org_id == current_user.org_id
).first()
```

### Prevention of Information Leakage
When a user attempts to read, modify, or activate a resource belonging to another organization, the API returns `404 Not Found` rather than a descriptive permission error (e.g. `403 Forbidden - Not your organization`). This prevents malicious actors from probing or enumerating resource IDs across tenant boundaries.

---

## 3. Immutability & Lifecycle Mechanics

### Why Separate `Skill` and `SkillVersion` Tables?
A `Skill` entity acts as a stable container for metadata (ID, Organization, Name, Department, Status, Active Version Pointer).

A `SkillVersion` entity represents an immutable snapshot of content and requested tools at a point in time.

### Lifecycle Rules:
1. **Draft Initial State**: Creating a skill inserts a `Skill` record (`status="draft"`) and a `SkillVersion` record (`version_number=1`, `status="pending_review"`).
2. **Immutable Edits**: Any edit to an active or existing skill creates `SkillVersion` N+1 with status `pending_review`. The existing active `SkillVersion` row is never updated in-place.
3. **Owner-Only Activation**: Only users with `role="owner"` can invoke `/activate`.
   - Supersedes any currently active version for that skill (`status="superseded"`).
   - Sets the target version's status to `"active"`.
   - Updates `skill.status = "active"` and `skill.current_active_version_id = version.id`.
4. **Idempotency Guarantee**: If an owner activates a version that is already active, the endpoint returns HTTP 200 OK immediately without modifying DB state or creating duplicate audit log entries.
5. **Tool Security**: Tool permissions in `requested_tools` are purely declarative metadata. They are validated against a strict denylist (`rm_rf`, `exec_shell`, `sudo`, `eval`, `system`, etc.) at version submission time and are **never** auto-granted or executed automatically by the backend.
