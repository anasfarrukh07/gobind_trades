# Production Deployment Guide: Org-Scoped Skill Registry

**Document Version**: 1.0.0  
**Target Audience**: Systems Administrators, DevOps Engineers, Client Technical Leads  
**Application**: Org-Scoped Skill Registry Backend Service (FastAPI + PostgreSQL)  

---

## 📋 Executive Overview

This document provides step-by-step instructions for deploying the **Org-Scoped Skill Registry Backend** to a production or staging environment. The application is containerized using Docker and uses PostgreSQL as its persistent relational database.

### System Requirements
- **Server**: Linux Virtual Private Server (AWS EC2, GCP Compute Engine, DigitalOcean Droplet, or On-Premise VM)
- **CPU / RAM**: Minimum 2 vCPUs, 2 GB RAM (Recommended: 4 vCPUs, 8 GB RAM for high concurrency)
- **Disk Space**: Minimum 20 GB SSD storage
- **Operating System**: Ubuntu 22.04 LTS or Debian 12 recommended
- **Software Dependencies**: Docker Engine (v24.0+), Docker Compose (v2.20+)

---

## 🛠️ Step 1: Environment Configuration

Before starting containers, create a production `.env` file containing secure credentials.

### 1.1 Generate Production Secrets
Generate a strong 64-character secret key for JWT signing:

```bash
openssl rand -hex 32
```

### 1.2 Create `.env` File
Create `/opt/skill-registry/.env` on the host machine with the following parameters:

```ini
# Environment
ENVIRONMENT=production

# Database Configuration
POSTGRES_USER=registry_prod_user
POSTGRES_PASSWORD=SECURE_DB_PASSWORD_CHANGE_ME_IN_PROD
POSTGRES_DB=skill_registry_prod
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

DATABASE_URL=postgresql://registry_prod_user:SECURE_DB_PASSWORD_CHANGE_ME_IN_PROD@postgres:5432/skill_registry_prod

# JWT Security
SECRET_KEY=YOUR_GENERATED_64_CHAR_HEX_SECRET_KEY
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=1440

# Domain & CORS
ALLOWED_ORIGINS=https://app.yourdomain.com,https://admin.yourdomain.com
```

> [!CAUTION]
> Never commit the `.env` file to version control. Restrict read permissions on the host server:
> `chmod 600 /opt/skill-registry/.env`

---

## 🐳 Step 2: Deployment via Docker Compose (Recommended)

This is the standard deployment model using containerized application and database services.

### 2.1 Clone Repository / Unpack Code
```bash
mkdir -p /opt/skill-registry
cd /opt/skill-registry
git clone <YOUR_GIT_REPOSITORY_URL> .
```

### 2.2 Launch Production Containers
Run Docker Compose in detached mode:

```bash
docker compose -f docker-compose.yml up -d --build
```

The container pipeline automatically:
1. Waits for PostgreSQL to pass health checks (`pg_isready`).
2. Executes Alembic database migrations (`alembic upgrade head`).
3. Seeds initial fixture organizations and owner accounts (`python -m app.seed`).
4. Starts the Uvicorn ASGI server listening on port `8000`.

### 2.3 Verify Container Status
```bash
docker compose ps
```
Both `skill_registry_api` and `skill_registry_db` should report state `running (healthy)`.

---

## 🔒 Step 3: Nginx Reverse Proxy & SSL/TLS Configuration

Do not expose Uvicorn directly to the public internet. Use Nginx as a reverse proxy with TLS encryption (HTTPS).

### 3.1 Install Nginx & Certbot
```bash
sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx
```

### 3.2 Configure Nginx Server Block
Create `/etc/nginx/sites-available/skill-registry`:

```nginx
server {
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeouts for API calls
        proxy_connect_timeout 60s;
        proxy_read_timeout 60s;
    }
}
```

Enable the configuration:
```bash
sudo ln -s /etc/nginx/sites-available/skill-registry /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 3.3 Obtain SSL Certificate (Let's Encrypt)
```bash
sudo certbot --nginx -d api.yourdomain.com
```

---

## ☁️ Option B: Managed Cloud Deployment (AWS / GCP / Azure)

If deploying to managed cloud infrastructure rather than a single VM:

| Service Component | AWS | Google Cloud (GCP) | Azure |
| :--- | :--- | :--- | :--- |
| **Managed Database** | Amazon RDS PostgreSQL | Cloud SQL for PostgreSQL | Azure Database for PostgreSQL |
| **Container Hosting** | AWS ECS / Fargate | Cloud Run | Azure Container Apps |
| **Secrets Engine** | AWS Secrets Manager | Secret Manager | Azure Key Vault |

1. Point `DATABASE_URL` to your managed PostgreSQL connection string.
2. Deploy the `Dockerfile` image to your container registry (ECR / GCR / ACR).
3. Run container command: `sh -c "alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port 8000"`

---

## 🏥 Operational Runbook & Maintenance

### Checking Live Logs
```bash
# View all logs
docker compose logs -f

# View API logs only
docker compose logs -f api
```

### Health Check Endpoint
```bash
curl https://api.yourdomain.com/health
```
*Expected response:* `{"status": "ok", "project": "Org-Scoped Skill Registry"}`

### Applying Database Migrations
When deploying updates with schema changes:

```bash
docker compose exec api alembic upgrade head
```

### Automated Database Backups
Set up a daily cron job to dump the PostgreSQL database to a backup directory:

```bash
crontab -e
```

Add the following entry (runs daily at 2:00 AM):

```bash
0 2 * * * docker exec skill_registry_db pg_dump -U registry_prod_user skill_registry_prod | gzip > /backups/skill_registry_$(date +\%Y\%m\%d).sql.gz
```

---

## 🛡️ Pre-Launch Security Checklist

- [ ] Changed default database passwords in `.env`.
- [ ] Generated unique `SECRET_KEY` for production JWT signing.
- [ ] Configured Uvicorn behind Nginx reverse proxy with HTTPS/TLS enabled.
- [ ] Restricted PostgreSQL port `5432` from public internet access via UFW / Cloud Firewall.
- [ ] Verified `GET /health` returns HTTP 200.
- [ ] Verified automated database backup cron job is active.

---

## 📞 Support & Contacts

For deployment assistance, system upgrades, or technical troubleshooting, please contact the engineering team.
