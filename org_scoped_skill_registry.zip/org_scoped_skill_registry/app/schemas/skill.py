from typing import Any, Dict, List, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.config import settings

def validate_tool_names(tools: List[str]) -> List[str]:
    denylist = settings.TOOL_DENYLIST
    for tool in tools:
        t_clean = tool.strip().lower()
        if t_clean in denylist or any(d in t_clean for d in ["exec", "rm_rf", "sudo", "format", "drop_db"]):
            raise ValueError(f"Requested tool '{tool}' is invalid or contains forbidden destructive patterns.")
    return tools

class SkillVersionCreate(BaseModel):
    content: Dict[str, Any] = Field(..., description="Skill version configuration/content JSON")
    requested_tools: List[str] = Field(default_factory=list, description="Requested tool permissions")

    @field_validator("requested_tools")
    @classmethod
    def check_tools(cls, v: List[str]) -> List[str]:
        return validate_tool_names(v)

class SkillVersionResponse(BaseModel):
    id: str
    skill_id: str
    version_number: int
    content: Dict[str, Any]
    requested_tools: List[str]
    status: str
    created_by: Optional[str]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class SkillCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    department: str = Field(..., min_length=1, max_length=255)
    content: Dict[str, Any] = Field(..., description="Initial version configuration/content")
    requested_tools: List[str] = Field(default_factory=list, description="Requested tools for version 1")

    @field_validator("requested_tools")
    @classmethod
    def check_tools(cls, v: List[str]) -> List[str]:
        return validate_tool_names(v)

class SkillResponse(BaseModel):
    id: str
    org_id: str
    name: str
    department: str
    status: str
    current_active_version_id: Optional[str]
    created_at: datetime
    updated_at: datetime
    versions: Optional[List[SkillVersionResponse]] = None

    model_config = ConfigDict(from_attributes=True)

class SkillDetailResponse(SkillResponse):
    versions: List[SkillVersionResponse]

