from typing import Any, Dict, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict

class AuditLogResponse(BaseModel):
    id: str
    org_id: str
    actor_id: Optional[str]
    event_type: str
    skill_id: str
    version_id: Optional[str]
    timestamp: datetime
    metadata_json: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(from_attributes=True)

