from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models.audit_log import AuditLog

def log_audit(
    db: Session,
    org_id: str,
    actor_id: str,
    event_type: str,
    skill_id: str,
    version_id: Optional[str] = None,
    metadata_json: Optional[Dict[str, Any]] = None
) -> AuditLog:
    log_entry = AuditLog(
        org_id=org_id,
        actor_id=actor_id,
        event_type=event_type,
        skill_id=skill_id,
        version_id=version_id,
        metadata_json=metadata_json
    )
    db.add(log_entry)
    db.flush()
    return log_entry
