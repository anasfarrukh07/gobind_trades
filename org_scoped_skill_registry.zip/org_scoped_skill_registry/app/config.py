import os
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "Org-Scoped Skill Registry"
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", 
        "postgresql://registry_user:registry_password@localhost:5432/skill_registry"
    )
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev_secret_key_never_use_in_prod_1234567890")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))

    # Tool Denylist - forbidden or destructive tool names
    TOOL_DENYLIST: set[str] = {
        "exec_shell",
        "rm_rf",
        "sudo",
        "eval",
        "system",
        "format_disk",
        "drop_database",
        "bash",
        "sh",
        "powershell",
        "cmd",
        "exec",
        "drop_table",
        "wipe_storage",
    }

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

