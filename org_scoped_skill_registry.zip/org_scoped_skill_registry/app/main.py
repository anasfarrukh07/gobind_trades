from fastapi import FastAPI
from app.config import settings
from app.api import auth, skills, departments, audit

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="FastAPI Backend for Org-Scoped Skill Registry with immutable versioning, tenant isolation, and audit logging.",
    version="1.0.0",
)

app.include_router(auth.router)
app.include_router(skills.router)
app.include_router(departments.router)
app.include_router(audit.router)

@app.get("/health", tags=["Health"])
def health_check():
    return {"status": "ok", "project": settings.PROJECT_NAME}
