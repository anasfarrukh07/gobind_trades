import uuid
from sqlalchemy import Column, String, Integer, DateTime, ForeignKey, JSON, func
from sqlalchemy.orm import relationship
from app.database import Base

class SkillVersion(Base):
    __tablename__ = "skill_versions"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    version_number = Column(Integer, nullable=False)
    content = Column(JSON, nullable=False)
    requested_tools = Column(JSON, nullable=False, default=list)
    status = Column(String(50), nullable=False, default="pending_review", index=True)  # 'pending_review', 'approved', 'active', 'superseded'
    created_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    skill = relationship("Skill", back_populates="versions", foreign_keys=[skill_id])
    creator = relationship("User", back_populates="versions_created")
    audit_logs = relationship("AuditLog", back_populates="version")
