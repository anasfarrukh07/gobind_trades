import uuid
from sqlalchemy import Column, String, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from app.database import Base

class Skill(Base):
    __tablename__ = "skills"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    org_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    department = Column(String(255), nullable=False, index=True)
    status = Column(String(50), nullable=False, default="draft", index=True)  # 'draft', 'active', 'disabled'
    current_active_version_id = Column(
        String(36),
        ForeignKey("skill_versions.id", use_alter=True, name="fk_skills_active_version_id", ondelete="SET NULL"),
        nullable=True
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    organization = relationship("Organization", back_populates="skills")
    versions = relationship("SkillVersion", back_populates="skill", foreign_keys="SkillVersion.skill_id", cascade="all, delete-orphan")
    active_version = relationship("SkillVersion", foreign_keys=[current_active_version_id], post_update=True)
    audit_logs = relationship("AuditLog", back_populates="skill", cascade="all, delete-orphan")
