from app.database import SessionLocal, engine, Base
from app.models.organization import Organization
from app.models.user import User
from app.auth.jwt import get_password_hash

def seed_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # Check if already seeded
        if db.query(Organization).filter(Organization.name == "ABC Construction").first():
            print("Database already seeded.")
            return

        print("Seeding database...")

        # Org 1: ABC Construction
        org_abc = Organization(name="ABC Construction")
        db.add(org_abc)
        db.flush()

        user_abc_owner = User(
            org_id=org_abc.id,
            email="owner@abc.com",
            role="owner",
            hashed_password=get_password_hash("Password123!")
        )
        user_abc_member = User(
            org_id=org_abc.id,
            email="member@abc.com",
            role="member",
            hashed_password=get_password_hash("Password123!")
        )
        db.add(user_abc_owner)
        db.add(user_abc_member)

        # Org 2: XYZ Builders
        org_xyz = Organization(name="XYZ Builders")
        db.add(org_xyz)
        db.flush()

        user_xyz_owner = User(
            org_id=org_xyz.id,
            email="owner@xyz.com",
            role="owner",
            hashed_password=get_password_hash("Password123!")
        )
        user_xyz_member = User(
            org_id=org_xyz.id,
            email="member@xyz.com",
            role="member",
            hashed_password=get_password_hash("Password123!")
        )
        db.add(user_xyz_owner)
        db.add(user_xyz_member)

        db.commit()
        print("Database seeding completed successfully.")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_db()
