from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User
from app.models.skill import Skill
from app.models.skill_version import SkillVersion
from app.auth.dependencies import get_current_user, require_owner
from app.crud.audit import log_audit
from app.schemas.skill import (
    SkillCreate,
    SkillResponse,
    SkillDetailResponse,
    SkillVersionCreate,
    SkillVersionResponse,
)

router = APIRouter(prefix="/skills", tags=["Skills"])

@router.post("", response_model=SkillDetailResponse, status_code=status.HTTP_201_CREATED)
def create_skill(
    skill_in: SkillCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    1. POST /skills — create draft skill with Version 1 (status: pending_review).
    """
    skill = Skill(
        org_id=current_user.org_id,
        name=skill_in.name,
        department=skill_in.department,
        status="draft",
        current_active_version_id=None,
    )
    db.add(skill)
    db.flush()

    version = SkillVersion(
        skill_id=skill.id,
        version_number=1,
        content=skill_in.content,
        requested_tools=skill_in.requested_tools,
        status="pending_review",
        created_by=current_user.id,
    )
    db.add(version)
    db.flush()

    log_audit(
        db=db,
        org_id=current_user.org_id,
        actor_id=current_user.id,
        event_type="version_created",
        skill_id=skill.id,
        version_id=version.id,
        metadata_json={"version_number": 1, "is_initial": True}
    )

    db.commit()
    db.refresh(skill)
    return skill

@router.get("", response_model=List[SkillResponse])
def list_skills(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    2. GET /skills — list skills for current org
    """
    skills = db.query(Skill).filter(Skill.org_id == current_user.org_id).all()
    return skills

@router.get("/{skill_id}", response_model=SkillDetailResponse)
def get_skill(
    skill_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    3. GET /skills/{id} — skill + all its versions (scoped strictly to org_id)
    """
    skill = db.query(Skill).filter(
        Skill.id == skill_id,
        Skill.org_id == current_user.org_id
    ).first()

    if not skill:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Skill not found"
        )
    return skill

@router.post("/{skill_id}/versions", response_model=SkillVersionResponse, status_code=status.HTTP_201_CREATED)
def create_skill_version(
    skill_id: str,
    version_in: SkillVersionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    4. POST /skills/{id}/versions — create new immutable version (Version N+1, status: pending_review)
    """
    skill = db.query(Skill).filter(
        Skill.id == skill_id,
        Skill.org_id == current_user.org_id
    ).first()

    if not skill:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Skill not found"
        )

    if skill.status == "disabled":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot add versions to a disabled skill"
        )

    # Calculate next version number
    max_version = db.query(SkillVersion).filter(SkillVersion.skill_id == skill.id).order_by(SkillVersion.version_number.desc()).first()
    next_version_num = (max_version.version_number + 1) if max_version else 1

    new_version = SkillVersion(
        skill_id=skill.id,
        version_number=next_version_num,
        content=version_in.content,
        requested_tools=version_in.requested_tools,
        status="pending_review",
        created_by=current_user.id
    )
    db.add(new_version)
    db.flush()

    log_audit(
        db=db,
        org_id=current_user.org_id,
        actor_id=current_user.id,
        event_type="version_created",
        skill_id=skill.id,
        version_id=new_version.id,
        metadata_json={"version_number": next_version_num}
    )

    db.commit()
    db.refresh(new_version)
    return new_version

@router.post("/{skill_id}/versions/{version_id}/activate", response_model=SkillDetailResponse)
def activate_skill_version(
    skill_id: str,
    version_id: str,
    current_user: User = Depends(require_owner),
    db: Session = Depends(get_db)
):
    """
    5. POST /skills/{id}/versions/{version_id}/activate — owner-only activation
    - Idempotent safe no-op if already active.
    - Sets skill.status=active, skill.current_active_version_id=version, version.status=active.
    - Supersedes prior active version if any.
    """
    skill = db.query(Skill).filter(
        Skill.id == skill_id,
        Skill.org_id == current_user.org_id
    ).first()

    if not skill:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Skill not found"
        )

    version = db.query(SkillVersion).filter(
        SkillVersion.id == version_id,
        SkillVersion.skill_id == skill.id
    ).first()

    if not version:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Skill version not found"
        )

    # IDEMPOTENCY CHECK: Duplicate activation of an already-active version must be a safe no-op
    if skill.status == "active" and skill.current_active_version_id == version.id and version.status == "active":
        return skill

    # Supersede existing active version(s)
    prior_active_versions = db.query(SkillVersion).filter(
        SkillVersion.skill_id == skill.id,
        SkillVersion.status == "active",
        SkillVersion.id != version.id
    ).all()
    for prev_ver in prior_active_versions:
        prev_ver.status = "superseded"

    # Activate requested version
    version.status = "active"
    skill.status = "active"
    skill.current_active_version_id = version.id

    log_audit(
        db=db,
        org_id=current_user.org_id,
        actor_id=current_user.id,
        event_type="version_activated",
        skill_id=skill.id,
        version_id=version.id,
        metadata_json={"version_number": version.version_number}
    )

    db.commit()
    db.refresh(skill)
    return skill

@router.post("/{skill_id}/disable", response_model=SkillDetailResponse)
def disable_skill(
    skill_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    6. POST /skills/{id}/disable — set skill status to disabled
    """
    skill = db.query(Skill).filter(
        Skill.id == skill_id,
        Skill.org_id == current_user.org_id
    ).first()

    if not skill:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Skill not found"
        )

    skill.status = "disabled"

    log_audit(
        db=db,
        org_id=current_user.org_id,
        actor_id=current_user.id,
        event_type="skill_disabled",
        skill_id=skill.id,
        version_id=skill.current_active_version_id,
        metadata_json={"previous_status": skill.status}
    )

    db.commit()
    db.refresh(skill)
    return skill
