from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User
from app.models.skill import Skill
from app.auth.dependencies import get_current_user
from app.schemas.skill import SkillDetailResponse

router = APIRouter(prefix="/departments", tags=["Departments"])

@router.get("/{dept}/active-skills", response_model=List[SkillDetailResponse])
def list_active_skills_for_department(
    dept: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    7. GET /departments/{dept}/active-skills — active skills for a department, org-scoped.
    Excludes draft and disabled skills.
    """
    skills = db.query(Skill).filter(
        Skill.org_id == current_user.org_id,
        Skill.department == dept,
        Skill.status == "active"
    ).all()

    return skills
